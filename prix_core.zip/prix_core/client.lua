print("[prix_core] Started successfully on client.")

function GetCoreStatus()
    return true
end