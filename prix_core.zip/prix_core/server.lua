print("[prix_core] Started successfully on server.")

function GetCoreStatus()
    return true
end