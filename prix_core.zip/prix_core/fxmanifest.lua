fx_version 'cerulean'
game 'gta5'

name 'prix_core'
author 'Freeroam Company'
description 'prix_core - Prix Core is a lightweight core script required by other resources.'
version '1.0'

server_script 'server.lua'
client_script 'client.lua'

exports {
    'GetCoreStatus'
}
